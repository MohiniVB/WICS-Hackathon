import pinecone
import openai
import json
import os

# Initialize Pinecone
pinecone.init(api_key="your_pinecone_api_key", environment="enter_environment")
index = pinecone.Index("medical-chatbot")

class MedicalChatbot:
    def __init__(self, openai_api_key):
        openai.api_key = openai_api_key
        self.patient_records = {}
        self.registered_patients = {
            "1234567890": {"dob": "01/01/1980", "id": "patient_001"},
            "9876543210": {"dob": "05/12/1995", "id": "patient_002"}
        }  # Example patient records

    def verify_patient(self, phone, dob):
        """Verifies if the patient exists in the system."""
        if phone in self.registered_patients and self.registered_patients[phone]["dob"] == dob:
            return self.registered_patients[phone]["id"]
        return None

    def store_conversation(self, patient_id, conversation):
        """Stores a patient's conversation in Pinecone."""
        index.upsert([(patient_id, {"text": json.dumps(conversation)})])
        self.patient_records[patient_id] = conversation

    def retrieve_similar_cases(self, patient_response):
        """Retrieves similar past conversations from Pinecone."""
        results = index.query(patient_response, top_k=3, include_metadata=True)
        return [json.loads(match['metadata']['text']) for match in results['matches']]

    def ask_openai(self, prompt, previous_context=""):
        """Generates relevant follow-up questions based on retrieved cases."""
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a medical assistant gathering patient history."},
                {"role": "user", "content": previous_context + "\n" + prompt}
            ]
        )
        return response['choices'][0]['message']['content']

    def dynamic_follow_up(self, patient_response, context):
        """Generates a follow-up question based on similar past cases."""
        similar_cases = self.retrieve_similar_cases(patient_response)
        context += "\n".join([json.dumps(case) for case in similar_cases])
        follow_up_prompt = f"Based on similar cases and the response: '{patient_response}', suggest a medically relevant follow-up question."
        return self.ask_openai(follow_up_prompt, context)

    def collect_history(self, patient_id):
        """Asks standard questions and adapts based on responses."""
        patient_data = {}
        context = ""

        questions = [
            "What symptoms are you experiencing?",
            "How severe is your pain on a scale of 1-10?",
            "Are there any triggers that worsen your symptoms?",
            "Do you have any known allergies?",
            "Are you currently taking any medications?",
            "Briefly, do you have any past medical conditions?",
            "Does your family have a history of any major illnesses?"
        ]

        for question in questions:
            response = input(question + " ")
            patient_data[question] = response
            context += f"\n{question}: {response}"

            follow_up = self.dynamic_follow_up(response, context)
            if follow_up:
                follow_up_response = input(follow_up + " ")
                patient_data[follow_up] = follow_up_response
                context += f"\n{follow_up}: {follow_up_response}"

        self.store_conversation(patient_id, patient_data)
        return patient_data

if __name__ == "__main__":
    chatbot = MedicalChatbot("your_openai_api_key")
    phone = input("Enter your phone number: ")
    dob = input("Enter your date of birth (MM/DD/YYYY): ")

    patient_id = chatbot.verify_patient(phone, dob)
    if patient_id:
        print("Verification successful. Proceeding with medical history collection.")
        patient_history = chatbot.collect_history(patient_id)
        print("Patient History Collected:", json.dumps(patient_history, indent=2))
    else:
        print("Patient not found. Please check your details and try again.")
