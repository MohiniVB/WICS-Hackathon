import sqlite3
import json

class PatientDatabase:
    def __init__(self, db_name="patients.db"):
        self.db_name = db_name
        self._create_table()

    def _create_table(self):
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS patients (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                phone_number TEXT UNIQUE,
                date_of_birth TEXT,
                data TEXT
            )
        ''')
        conn.commit()
        conn.close()

    def verify_patient(self, phone, dob):
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM patients WHERE phone_number = ? AND date_of_birth = ?", (phone, dob))
        patient = cursor.fetchone()
        conn.close()
        return patient

    def store_patient_data(self, phone, dob, data):
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        cursor.execute("UPDATE patients SET data = ? WHERE phone_number = ? AND date_of_birth = ?", 
                       (json.dumps(data), phone, dob))
        conn.commit()
        conn.close()
