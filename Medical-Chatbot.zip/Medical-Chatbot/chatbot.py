import openai
from database import PatientDatabase

class MedicalChatbot:
    def __init__(self, openai_api_key):
        openai.api_key = openai_api_key
        self.db = PatientDatabase()

    def ask_openai(self, prompt, previous_context=""):
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a medical assistant gathering patient history."},
                {"role": "user", "content": previous_context + "\n" + prompt}
            ]
        )
        return response['choices'][0]['message']['content']

    def dynamic_follow_up(self, response, context):
        follow_up_prompt = f"Based on the patient's response: '{response}', ask a medically relevant follow-up question if necessary. If the response is clear, return 'No further questions'."
        follow_up = self.ask_openai(follow_up_prompt, context)
        return follow_up if follow_up != "No further questions" else None

    def collect_history(self, phone, dob):
        if not self.db.verify_patient(phone, dob):
            return "Patient not found. Please register first."

        patient_data = {"Phone": phone, "DOB": dob}
        context = ""

        questions = [
            "What is your full name?",
            "What is your gender?",
            "What symptoms are you experiencing?",
            "How severe is your pain on a scale of 1-10?",
            "Are there any triggers that worsen your symptoms?",
            "Do you have any known allergies?",
            "Are you currently taking any medications?",
            "Briefly, do you have any past medical conditions?",
            "Does your family have a history of any major illnesses?"
        ]

        for question in questions:
            response = self.ask_openai(question, context)
            patient_data[question] = response
            context += f"\n{question}: {response}"

            follow_up = self.dynamic_follow_up(response, context)
            while follow_up:
                follow_up_response = self.ask_openai(follow_up, context)
                patient_data[follow_up] = follow_up_response
                context += f"\n{follow_up}: {follow_up_response}"
                follow_up = self.dynamic_follow_up(follow_up_response, context)

        self.db.store_patient_data(phone, dob, patient_data)
        return "Patient history saved successfully."
