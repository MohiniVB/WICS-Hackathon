from flask import Flask, request, jsonify
from chatbot import MedicalChatbot

app = Flask(__name__)

chatbot = MedicalChatbot("your_openai_api_key_here")  # Replace with actual API key

@app.route("/collect_history", methods=["POST"])
def collect_history():
    data = request.json
    phone = data.get("phone")
    dob = data.get("dob")
    if not phone or not dob:
        return jsonify({"error": "Phone number and DOB are required"}), 400

    result = chatbot.collect_history(phone, dob)
    return jsonify({"message": result})

if __name__ == "__main__":
    app.run(debug=True)
